<!--
 * @Author: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @Date: 2024-07-12 08:27:58
 * @LastEditors: error: error: git config user.name & please set dead value or install git && error: git config user.email & please set dead value or install git & please set dead value or install git
 * @LastEditTime: 2024-07-26 14:28:11
 * @FilePath: /Doorbell/README.md
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
# 更新说明
1.优化人形侦测画框功能
2.优化开锁提示音

## 20240720
1.修改ADC采集键值

## 20240722
1.修改呼叫参数回铃声设置标志位
2.优化红外灯光
3.修改sync同步为fsync
4.修复夜间红外进入视频未切换夜视问题


## 20240726
1.优化夜间红外灯光常亮

## 20250120
1.优化底层库

## 20250208
1.添加开锁语音播报

## 20250211
1.修复警报触发后呼叫灯在未监控下常亮问题,在警报结束后判断是否处于监控来控制呼叫灯

## 20250304
1.添加网卡接收异常后重启网卡设备处理-NetMsgcomm.c、NetworkRaw.c

## 20250308
1.添加获取本地设备ID接口
2.修复接收到视频通话消息未作校验确认是否对象是本机，将该校验逻辑补上修复该问题
3.修复红外切换阻塞问题，其原因是定时器抢占了安凯视频采集配置线程，执行夜视效果切换，导致其安凯接口内部阻塞，解决方案如4
4.优化视频采集夜视切换及I帧请求接口，将该功能更改为原子标志位，具体切换请求放到视频采集线程处理
5.修复运行初死机，原因：在定时器结构体未初始化前，红外检测线程调用了该接口，后定时器结构体初始化时将数据重新清除，导致数据丢失，段错误；解决方法，为了避免定时器使用受初始化流程影响，将定时器结构体数组静态赋值，在程序编译时完成初始化,并删除mian函数中Timer_init函数调用及删除该函数
6.在CircularListRequest申请节点时，避免节点在申请后未使用，导致下次申请失败，后续所有节点的申请都必须重新写入到队列中；此问题分别修改了语音播放、音频输出等相关队列
7.优化红外检测功能，红外中断触发后开启或刷新红外电平稳定检测定时器，定时器开启期间中断触发重新刷新计时，定时结束作一次有效检测，定时时间一秒
8.优化循环队列源码，优化语音播放源码
9.添加用户默认配置文件，添加默认配置文件保存接口
10.优化管理员、开锁等密码设置功能，新增密码范围控制，支持4-6位开锁密码
11.优化数字键盘修改语言命令，添加默认出厂语言设置功能
    (1)修改默认出厂语言指令 9 + DEFAULT_FACTORY_SET_FLAG + language + #    (DEFAULT_FACTORY_SET_FLAG = 9)
    (2)修改语言指令 9 + language + #
12.优化数字按键公共密码开锁指令，添加默认出厂密码设置功能
    (1)修改默认出厂Lock锁公共密码指令 011 + DEFAULT_FACTORY_SET_FLAG + 新密码 + # + 二次确认密码 + #
    (2)修改默认出厂Lock锁公共密码指令 022 + DEFAULT_FACTORY_SET_FLAG + 新密码 + # + 二次确认密码 + #
13.修复管理员模式下*返回后未关闭30秒超时退出管理员定时器
14.优化PushRouteStack接口逻辑，删除该接口ExitHandle回调函数调用操作

## 20250311
1.修复夜视监控退出后红外灯保持常亮及夜视状态进入监控红外灯未开启问题
2.修复上电协商慢导致网卡重启操作，引起套接字无法正常工作问题，修改逻辑：检测到正常工作后异常才开启网卡重启处理

## 20250312
1.修复卡组格式化异常，函数接口在清零时传入结构体类型得到错误的大小，导致仅清除一组数据，将整个数组传入sizeof解决问题
2.修复卡片密码开锁失败问题
3.修复在修改卡片密码时，为销毁定时器而设置一毫秒触发导致在其他操作销毁定时器时冲突，死机
4.定时器添加原子操作，防止二次删除竞争操作
5.添加荷兰及斯洛伐克语
